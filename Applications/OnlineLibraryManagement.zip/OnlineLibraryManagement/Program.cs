﻿using System;
namespace OnlineLibraryManagement;
class Program
{
    public static void Main(string[] args)
    {
        //For adding the default values
        Operations.AddingDefaultDatas();

        //MainMenu calling
        Operations.MainMenu();
    }
}